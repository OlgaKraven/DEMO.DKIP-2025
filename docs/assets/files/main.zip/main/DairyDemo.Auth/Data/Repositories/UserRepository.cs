﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using DairyDemo.Auth.Data.Models;
using MySqlConnector;

namespace DairyDemo.Auth.Data.Repositories;

public sealed class UserRepository
{
    public async Task<User?> GetByLoginAsync(string login)
    {
        await using var conn = Db.CreateConnection();
        await conn.OpenAsync();

        const string sql = @"
SELECT id, login, password_hash, role, failed_attempts, is_locked
FROM users
WHERE login = @login
LIMIT 1;
";
        await using var cmd = new MySqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@login", login);

        await using var r = await cmd.ExecuteReaderAsync();
        if (!await r.ReadAsync()) return null;

        return new User
        {
            Id = r.GetInt64("id"),
            Login = r.GetString("login"),
            PasswordHash = r.GetString("password_hash"),
            Role = r.GetString("role"),
            FailedAttempts = r.GetInt32("failed_attempts"),
            IsLocked = r.GetBoolean("is_locked")
        };
    }

    public async Task<List<User>> GetAllAsync()
    {
        await using var conn = Db.CreateConnection();
        await conn.OpenAsync();

        const string sql = @"
SELECT id, login, password_hash, role, failed_attempts, is_locked
FROM users
ORDER BY id;
";
        await using var cmd = new MySqlCommand(sql, conn);

        var list = new List<User>();
        await using var r = await cmd.ExecuteReaderAsync();
        while (await r.ReadAsync())
        {
            list.Add(new User
            {
                Id = r.GetInt64("id"),
                Login = r.GetString("login"),
                PasswordHash = r.GetString("password_hash"),
                Role = r.GetString("role"),
                FailedAttempts = r.GetInt32("failed_attempts"),
                IsLocked = r.GetBoolean("is_locked")
            });
        }

        return list;
    }

    public async Task<bool> ExistsLoginAsync(string login)
    {
        await using var conn = Db.CreateConnection();
        await conn.OpenAsync();

        const string sql = @"SELECT 1 FROM users WHERE login = @login LIMIT 1;";
        await using var cmd = new MySqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@login", login);

        var res = await cmd.ExecuteScalarAsync();
        return res != null;
    }

    public async Task AddUserAsync(string login, string passwordHash, string role)
    {
        await using var conn = Db.CreateConnection();
        await conn.OpenAsync();

        const string sql = @"
INSERT INTO users (login, password_hash, role)
VALUES (@login, @hash, @role);
";
        await using var cmd = new MySqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@login", login);
        cmd.Parameters.AddWithValue("@hash", passwordHash);
        cmd.Parameters.AddWithValue("@role", role);

        await cmd.ExecuteNonQueryAsync();
    }

    public async Task UpdateUserAsync(long id, string login, string role)
    {
        await using var conn = Db.CreateConnection();
        await conn.OpenAsync();

        const string sql = @"
UPDATE users
SET login = @login,
    role  = @role
WHERE id = @id;
";
        await using var cmd = new MySqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", id);
        cmd.Parameters.AddWithValue("@login", login);
        cmd.Parameters.AddWithValue("@role", role);

        await cmd.ExecuteNonQueryAsync();
    }

    public async Task UpdatePasswordAsync(long id, string passwordHash)
    {
        await using var conn = Db.CreateConnection();
        await conn.OpenAsync();

        const string sql = @"UPDATE users SET password_hash = @hash WHERE id = @id;";
        await using var cmd = new MySqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", id);
        cmd.Parameters.AddWithValue("@hash", passwordHash);

        await cmd.ExecuteNonQueryAsync();
    }

    public async Task IncrementFailedAttemptsAndLockIfNeededAsync(long userId)
    {
        await using var conn = Db.CreateConnection();
        await conn.OpenAsync();

        // MySQL: boolean обычно хранится как TINYINT(1), поэтому выставляем 1/0.
        const string sql = @"
UPDATE users
SET failed_attempts = failed_attempts + 1,
    is_locked = CASE
        WHEN (failed_attempts + 1) >= 3 THEN 1
        ELSE is_locked
    END
WHERE id = @id;
";
        await using var cmd = new MySqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", userId);

        await cmd.ExecuteNonQueryAsync();
    }

    public async Task ResetFailedAttemptsAsync(long userId)
    {
        await using var conn = Db.CreateConnection();
        await conn.OpenAsync();

        const string sql = @"UPDATE users SET failed_attempts = 0 WHERE id = @id;";
        await using var cmd = new MySqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", userId);

        await cmd.ExecuteNonQueryAsync();
    }

    public async Task UnlockAsync(long userId)
    {
        await using var conn = Db.CreateConnection();
        await conn.OpenAsync();

        const string sql = @"UPDATE users SET failed_attempts = 0, is_locked = 0 WHERE id = @id;";
        await using var cmd = new MySqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", userId);

        await cmd.ExecuteNonQueryAsync();
    }

    // (опционально) Удобно получать ID последней вставки при добавлении пользователя.
    // public async Task<long> AddUserAndReturnIdAsync(string login, string passwordHash, string role)
    // {
    //     await using var conn = Db.CreateConnection();
    //     await conn.OpenAsync();
    //
    //     const string sql = @"
    // INSERT INTO users (login, password_hash, role)
    // VALUES (@login, @hash, @role);
    // SELECT LAST_INSERT_ID();
    // ";
    //     await using var cmd = new MySqlCommand(sql, conn);
    //     cmd.Parameters.AddWithValue("@login", login);
    //     cmd.Parameters.AddWithValue("@hash", passwordHash);
    //     cmd.Parameters.AddWithValue("@role", role);
    //
    //     var id = await cmd.ExecuteScalarAsync();
    //     return Convert.ToInt64(id);
    // }
}
