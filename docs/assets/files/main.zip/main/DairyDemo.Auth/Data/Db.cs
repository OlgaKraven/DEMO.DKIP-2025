﻿using MySqlConnector;

namespace DairyDemo.Auth.Data;

public static class Db
{
    // Пример для XAMPP:
    // user: root
    // password: (часто пустой, если вы не меняли)
    // host: localhost
    // database: dairy_demo
    public static string ConnectionString =
        "Server=localhost;Port=3306;Database=dairy_demo;Uid=root;Pwd=;SslMode=None;";

    public static MySqlConnection CreateConnection()
        => new MySqlConnection(ConnectionString);
}